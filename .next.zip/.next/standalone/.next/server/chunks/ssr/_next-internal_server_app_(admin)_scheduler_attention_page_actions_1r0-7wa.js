module.exports=[96393,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_attention_page_actions_1r0-7wa.js.map