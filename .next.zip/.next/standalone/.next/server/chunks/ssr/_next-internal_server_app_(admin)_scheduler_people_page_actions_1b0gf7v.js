module.exports=[52818,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_people_page_actions_1b0gf7v.js.map