module.exports=[70158,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_teachers_page_actions_0nsclpt.js.map