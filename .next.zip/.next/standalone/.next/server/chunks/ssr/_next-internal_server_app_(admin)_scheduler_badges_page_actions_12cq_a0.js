module.exports=[20630,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_badges_page_actions_12cq_a0.js.map