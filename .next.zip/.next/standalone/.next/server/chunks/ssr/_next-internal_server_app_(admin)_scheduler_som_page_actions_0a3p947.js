module.exports=[3787,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_som_page_actions_0a3p947.js.map