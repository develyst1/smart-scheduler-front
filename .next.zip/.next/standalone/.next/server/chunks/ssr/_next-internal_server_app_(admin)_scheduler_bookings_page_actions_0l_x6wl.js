module.exports=[96691,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_bookings_page_actions_0l_x6wl.js.map