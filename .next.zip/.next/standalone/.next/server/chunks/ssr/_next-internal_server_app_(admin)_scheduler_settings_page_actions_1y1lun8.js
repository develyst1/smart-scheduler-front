module.exports=[2935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_settings_page_actions_1y1lun8.js.map