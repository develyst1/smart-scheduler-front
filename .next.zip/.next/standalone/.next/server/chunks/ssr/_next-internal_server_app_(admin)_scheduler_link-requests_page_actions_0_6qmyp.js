module.exports=[23074,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_scheduler_link-requests_page_actions_0_6qmyp.js.map