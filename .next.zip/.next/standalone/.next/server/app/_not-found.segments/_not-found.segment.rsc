1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0tgg2weurxdkr.js","/_next/static/chunks/2309mnfc8c24-.js","/_next/static/chunks/00ew9ukomqsti.js","/_next/static/chunks/0fckgllnlklbq.js","/_next/static/chunks/3r1qtfsmp7vrh.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
3:I[37457,["/_next/static/chunks/0tgg2weurxdkr.js","/_next/static/chunks/2309mnfc8c24-.js","/_next/static/chunks/00ew9ukomqsti.js","/_next/static/chunks/0fckgllnlklbq.js","/_next/static/chunks/3r1qtfsmp7vrh.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"ArmehAxF94sMGnzTWCiWo"}
