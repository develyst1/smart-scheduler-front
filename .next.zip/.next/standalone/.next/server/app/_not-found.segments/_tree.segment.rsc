:HL["/_next/static/chunks/2fybn5_k7fwe_.css","style"]
:HL["/_next/static/chunks/3lco7hsqgh_8h.css","style"]
:HL["/_next/static/chunks/42m5ir52k3m90.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"ArmehAxF94sMGnzTWCiWo"}
