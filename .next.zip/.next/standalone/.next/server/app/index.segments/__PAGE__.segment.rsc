1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0tgg2weurxdkr.js","/_next/static/chunks/2309mnfc8c24-.js","/_next/static/chunks/00ew9ukomqsti.js","/_next/static/chunks/0fckgllnlklbq.js","/_next/static/chunks/3r1qtfsmp7vrh.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ArmehAxF94sMGnzTWCiWo"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/scheduler/calendar;307;"}
