1:"$Sreact.fragment"
2:I[52000,["/_next/static/chunks/0tgg2weurxdkr.js","/_next/static/chunks/2309mnfc8c24-.js","/_next/static/chunks/00ew9ukomqsti.js","/_next/static/chunks/0fckgllnlklbq.js","/_next/static/chunks/3r1qtfsmp7vrh.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/3q_-_tdy4u3s0.js","/_next/static/chunks/0dmbayl_jugic.js","/_next/static/chunks/1sfouicc-jy5u.js","/_next/static/chunks/0atwn4xm1c2ag.js","/_next/static/chunks/1r8n897g-ipg8.js","/_next/static/chunks/1cl8-_ty-bakv.js","/_next/static/chunks/0cg1sapmund5x.js"],"default"]
3:I[97367,["/_next/static/chunks/0tgg2weurxdkr.js","/_next/static/chunks/2309mnfc8c24-.js","/_next/static/chunks/00ew9ukomqsti.js","/_next/static/chunks/0fckgllnlklbq.js","/_next/static/chunks/3r1qtfsmp7vrh.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0cg1sapmund5x.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ArmehAxF94sMGnzTWCiWo"}
5:null
