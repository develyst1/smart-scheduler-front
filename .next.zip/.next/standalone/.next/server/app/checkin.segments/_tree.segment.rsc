:HL["/_next/static/chunks/2fybn5_k7fwe_.css","style"]
:HL["/_next/static/chunks/3lco7hsqgh_8h.css","style"]
:HL["/_next/static/chunks/42m5ir52k3m90.css","style"]
:HL["/_next/static/media/bfd813093b8ca1bb-s.p.3ok2djvs6w93k.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/f304c3cf3765fb5f-s.p.0h0-3wqrkgcb1.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"checkin","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"ArmehAxF94sMGnzTWCiWo"}
