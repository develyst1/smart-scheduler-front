var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__17q652l._.js")
R.c("server/chunks/[root-of-the-server]__0yi5pep._.js")
R.m(89997)
module.exports=R.m(89997).exports
