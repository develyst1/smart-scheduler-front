globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ArmehAxF94sMGnzTWCiWo/_buildManifest.js",
    "static/ArmehAxF94sMGnzTWCiWo/_ssgManifest.js",
    "static/ArmehAxF94sMGnzTWCiWo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/0rpgm1fo52fiv.js",
    "static/chunks/2py1iotuundz4.js",
    "static/chunks/0vqmbxs8ror-0.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-05ozwalytkzx3.js"
  ]
};
